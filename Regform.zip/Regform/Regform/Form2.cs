﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace Regform
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string sql = "select * from reg where username='" + txtUnm.Text + "' AND password='" + txtPassword.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            int b = da.Fill(dt);
        }

        private void clear()
        {
            txtUnm.Text = "";
            txtPassword.Text = "";
            txtUnm.Focus();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Reg().Show();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Reg().Show();
        }
    }
}
