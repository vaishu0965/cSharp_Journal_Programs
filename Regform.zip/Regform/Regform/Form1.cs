﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Regform
{
    public partial class Reg : Form
    {
        public Reg()
        {
            InitializeComponent();
        }

        private void txtUnm_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String query = "insert into reg values('" + txtUnm.Text + "','" + txtPassword.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(query, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            clear();
        }

        private void clear()
        {
            txtUnm.Text = "";
            txtPassword.Text = "";
            txtUnm.Focus();
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Login().Show();
        }
    }
}
